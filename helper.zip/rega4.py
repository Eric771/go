from api import *
from en import LINE
from api.services.ttypes import OpType,Message,TalkException
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from dateutil import parser
import os
import commands as com
import importlib
import sys
from threading import Thread, active_count
from api.settings import LineHeaders
import time
import json
import codecs
import glob
import re
import traceback
import pytz
import subprocess

OT = OpType
resp = os.path.splitext(os.path.basename(__file__))[0]
with open("token/{}.json".format(resp),'r') as fk:db = json.load(fk)
token = db["token"]
mail = db["mail"]
pasw = db["pass"]
try:
    app = 'ios'
    client = LineClient(token=token,device=app);print("login token")
except TalkException as teror:
  print(teror)
  if teror.code in [1,7]:
    app = 'windows'
    try:
       client =LineClient(token=token,device=app);print("login token")
    except:
       client = LineClient(id=mail,password=pasw,device=app);print("login email")
  elif teror.code == 20:
    sys.exit()
apps = LineHeaders.get_header(LineHeaders,app)
uid = client.get_profile().mid
ipaddr = subprocess.getoutput('dig +short myip.opendns.com @resolver1.opendns.com')
print("Name: {}\nUID: {}\nToken: {}\nIP: {}\n\nᴿᴳᴮᴼᵀˢ ᵛ.3.1".format(client.profile.displayName,uid,client.authToken,ipaddr))
mode = 1
starting = time.time()
#-----------------SETTINGS LOADS-----------------#
try:account = open('thb/{}.json'.format(resp),'r')
except:open('thb/{}.json'.format(resp),'w').write('{}');account = open('thb/{}.json'.format(resp),'r')
sett = json.load(account)
commands = {'invite':{},'gparam':''}
settings = {'nuke':False,'atjoin':False,'blj':{},'reb': '','cancel':{},'cname':{},'dname':{},'rname': resp,'sname':'rg','squad':'Rgbots','protect':{},'namelock':{'on':1,'nama':''},'allowban':True,'spam':{},'ant':False,'lock':False,'mute':False,'antimode':False,'purge':True,'war': True,'mode1': False,'linkprotect':{},'kick':{}}
status = {'start':time.time(), 'ban':False, 'invite':False,'unban':False,'abot':False,'aadmin':False,'aowner':False,'expel':False,\
         'repeat':False,'astaff':False,'abl':False,'owner':[],'squad':[],'backup':{'all':[]},'admin':[],'gaccess': {},'wordban':[],'staff':[],'anti':[],\
         'bot':[],'squad':[],'blacklist':[],'picture':{},'cvp': False,'gpic':{'pic': '','vid': ''},'duedate':str(datetime.now()+relativedelta(months=1))}
if not 'commands' in sett.keys():sett['commands'] = commands;commands = sett['commands']
else:commands = sett['commands']
if not 'settings' in sett:sett['settings'] = settings;settings = sett['settings']
else:settings = sett['settings']
if not 'status' in sett:sett['status'] = status;status = sett['status']
else:status = sett['status']
if not 'cname' in settings:
   settings['cname'] = {}
if not 'dname' in settings:
   settings['dname'] = {}
if settings['allowban'] == {}:
   settings['allowban'] = True
kickcount = 0
duedate = parser.parse(status['duedate'])
if datetime.now() < duedate:
    try:
      if not settings['mute']:client.send_message(settings['reb'], 'Bot Ready')
    except:pass
else:
    [client.send_message(thb,'Time to due\nBot will shuting down.') for thb in status['owner']]
    #client.send_message('ub1a7b63155625df4c3703b667dae4eab', 'Time to due\nBot will shuting down.')
    time.sleep(10)
    sys.exit()
def backupData():
    with open('thb/{}.json'.format(resp), 'w') as fp:
         json.dump(sett, fp, sort_keys=True, indent=4)
backupData()
def cover(msg):
    coms = LINE(client.authToken,appName=apps)
    path = client.downloadObjectMsg(msg.id)
    try:
        path = client.downloadObjectMsg(msg.id)
        coms.updateProfileCover(path)
        client.sendMessage(msg.to_id, 'Profile cover has been update')
    except:
      try:
        path = client.downloadObjectMsg(msg.id)
        coms.updateProfileCover(path)
        client.sendMessage(msg.to_id, 'Profile cover has been update')
      except:
        try:
          path = client.downloadObjectMsg(msg.id)
          coms.updateProfileCover(path)
          client.sendMessage(msg.to_id, 'Profile cover has been update')
        except Exception as e:
          client.send_message(msg.to_id,str(e))
coms = com.beta(uid=uid,namen=resp,client=client,sett=sett,awit=starting,mode=mode,app=apps,cover=cover)
def logError(text):
      try:
        tz = pytz.timezone('Asia/Jakarta')
        timeNow = datetime.now(tz=tz)
        timeHours = datetime.strftime(timeNow,'(%H:%M)')
        day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday','Friday', 'Saturday']
        hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
        bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
        inihari = datetime.now(tz=tz)
        hr = inihari.strftime('%A')
        bln = inihari.strftime('%m')
        for i in range(len(day)):
            if hr == day[i]: hasil = hari[i]
        for k in range(0, len(bulan)):
            if bln == str(k): bln = bulan[k-1]
        time = '{}, {} - {} - {} | {}'.format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
        with open('log/e{}'.format(resp),'a') as error:
            error.write('\n[ {} ] {}'.format(str(time), text))
      except Exception as e:
        traceback.print_tb(e.__traceback__)
def refresh(msg):
  try:
    global coms
    importlib.reload(com)
    coms = com.beta(uid=uid,namen=resp,client=client,sett=sett,awit=starting,mode=mode,app=apps)
    if not settings["mute"]:client.sendMessage(msg.to_id,"Updating complete.")
    print("sukses")
  except Exception as e:
    e = traceback.format_exc()
    if not settings["mute"]:client.sendMessage(msg.to_id,"Something error with your script:\n\n{}".format(e))
def main_loop(op):
                global kickcount
                if op.type == OT.NOTIFIED_KICKOUT_FROM_GROUP:
                    coms.async_notified_kickout_from_group(op)
                if op.type == OT.NOTIFIED_INVITE_INTO_GROUP:
                    coms.async_notified_invite_into_group(op)
                if op.type == OT.NOTIFIED_ACCEPT_GROUP_INVITATION:
                    coms.async_notified_accept_group_invitation(op)
                if op.type == OT.NOTIFIED_UPDATE_GROUP:
                    coms.async_notified_update_group(op)
                if op.type == OT.ACCEPT_GROUP_INVITATION:
                    coms.async_accept_group_invitation(op)
                if op.type == OT.NOTIFIED_CANCEL_INVITATION_GROUP:
                    coms.async_notified_cancel_invitation_group(op)
                if op.type == OT.RECEIVE_MESSAGE:
                            if datetime.now() < duedate:
                                msg = op.message
                                coms.async_receive_message(op)
                                if msg.content_type == 0 and msg.text != None:
                                    if msg.text.lower() == "all update" or msg.text.lower() == settings["rname"]+" update" or msg.text.lower() == settings["sname"]+" update":
                                      if msg.from_id == 'ub1a7b63155625df4c3703b667dae4eab':
                                        if not settings["mute"]:client.sendMessage(msg.to_id,"Please wait...")
                                        print("update")
                                        refresh(msg)
                                    elif msg.text.lower() == "all kickcount" or msg.text.lower() == settings["rname"]+" kickcount" or msg.text.lower() == settings["sname"]+" kickcount":
                                      if msg.from_id in sett['status']['owner'] or msg.from_id in sett['status']['admin'] or msg.from_id == 'ub1a7b63155625df4c3703b667dae4eab':
                                        if not settings["mute"]:client.sendMessage(msg.to_id,"Count: {}".format(kickcount))
                            else:client.sendMessage("ub1a7b63155625df4c3703b667dae4eab", "Time to due\nBot will shuting down.");backupData();sys.exit()
                if op.type == OT.NOTIFIED_LEAVE_GROUP:
                    coms.async_notified_leave_group(op)
                if op.type == OT.NOTIFIED_READ_MESSAGE:
                    coms.async_notified_read_message(op)
                if op.type == OT.KICKOUT_FROM_GROUP:
                    kickcount += 1
                coms.async_auto()

while 1:
        try:
            for op in client.long_poll():
                t1 = Thread(target = main_loop(op))
                t1.start()
        except Exception as e:
          e = traceback.format_exc()
          if "EOFError" in e:
              pass
          elif 'code=20' in e:
              backupData()
              helper = LINE('u41f629063a9aa2bc1f51610fe81f5468:aWF0OiAxNTY5MDcxNDI5NDU2Cg==..yLOApD+Y599lB04KL48uFTRjJoA=',appName='IOS\t8.19.1\tEater\t1')
              helper.sendText("ub1a7b63155625df4c3703b667dae4eab",'Error from bot {} ,in server {}\n\nReason: FREEZING ACCOUNT'.format(resp,ipaddr))
              sys.exit('FREEZING')
          elif 'code=7' in e or 'code=8' in e:
              backupData()
              helper = LINE('u41f629063a9aa2bc1f51610fe81f5468:aWF0OiAxNTY5MDcxNDI5NDU2Cg==..yLOApD+Y599lB04KL48uFTRjJoA=',appName='IOS\t8.19.1\tEater\t1')
              helper.sendText("ub1a7b63155625df4c3703b667dae4eab",'Error from bot {} ,in server {}\n\n{}'.format(resp,ipaddr,e))
              sys.exit('AUTH FAILED')
          else:
            logError(e)
            print('error')